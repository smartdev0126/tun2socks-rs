#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

void run(int fd, const char *handler, const char *server, const char *password, const char *cipher);
